#define _GNU_SOURCE
#include <stdio.h>
#include "welcome.c"
int main() {
    welcomeinfo * tmp = welcome();
    if(tmp->purpose == 0) {
	printf("The user wants to quit\n");
    }
    else if(tmp->purpose == 1) {
	printf("The user wants to login\n");
	printf("Name is %s\n", tmp->name);
	printf("Password is %s\n", tmp->password);
    }
    else {
	printf("The user wants to signup\n");
	printf("Name is %s\n", tmp->name);
        printf("Password is %s\n", tmp->password);
    }
}
