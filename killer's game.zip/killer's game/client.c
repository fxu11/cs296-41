#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <unistd.h>
#include <pthread.h>

#include "welcome.c"
#include "processServer.c"
#include "alloc.c"

int sock_fd;

int main(int argc, char **argv)
{
    welcomeinfo * uinfo = welcome();
    if(uinfo->purpose == 0) return 0;

    int s;
    sock_fd = socket(AF_INET, SOCK_STREAM, 0);

    struct addrinfo hints, *result;
    memset(&hints, 0, sizeof(struct addrinfo));
    hints.ai_family = AF_INET; /* IPv4 only */
    hints.ai_socktype = SOCK_STREAM; /* TCP */

    s = getaddrinfo(NULL, "1234", &hints, &result);
    if (s != 0) {
            fprintf(stderr, "getaddrinfo: %s\n", gai_strerror(s));
            exit(1);
    }

    int co = connect(sock_fd, result->ai_addr, result->ai_addrlen);
    if(co != 0) {
	fprintf(stderr, "connect : %s\n", gai_strerror(co));
	exit(1);
    }   

    write(sock_fd, "UIUC\0", 5); 
    char buffer[50];
    read(sock_fd, buffer, 10);
    if(strcmp(buffer, "CHAMPAIGN\0") != 0) {
	fprintf(stderr, "wrong server responding!\n");
	exit(1);
    }

    memset(buffer, 0, 50);
    write(sock_fd, uinfo, sizeof(welcomeinfo));
    read(sock_fd, buffer, 50);

    char rt[5];
    memcpy(rt, buffer, 4*sizeof(char));
    rt[5] = '\0';

    //printf("%s\n", rt);

    if(strncmp(rt, "SUCC", 4) != 0) {
        if(uinfo->purpose == 1) printf("Incorrect combination of username and password!\n");
        else if(uinfo->purpose == 2) printf("Sign up failed! The username already exist!\n");
        else printf("error occured!\n");
        exit(1);
    }
    int code = 0;
    memcpy(&code, buffer + 4, sizeof(int));
    printf("The code is %d\n", code);

    client_thread_input * tmp = calloc(sizeof(client_thread_input), 1);
    sem_init(&tmp->sem, 0, 0);    
    tmp->sock_fd = sock_fd;
    pthread_t t1, t2;
    pthread_mutex_lock(&mu);
    pthread_create(&t1, NULL, processServerIn, tmp);
    pthread_create(&t2, NULL, processServerOut, tmp);
    pthread_mutex_unlock(&mu);
    pthread_join(t1, NULL);
    pthread_join(t2, NULL);   
    
    return 0;
}
