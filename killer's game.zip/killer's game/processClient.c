#ifndef _PROCESSCLIENT_
#define _PROCESSCLIENT_
#include <stdlib.h>
#include <time.h>
#include <stdbool.h>
#include <string.h>
#include <unistd.h>
#include <sys/epoll.h>
#include <semaphore.h>

#include "welcome.c"
#include "userDatabase.c"
#include "room.c"

extern userDataBase * database;
extern lobby * hall;

/*
int inHall;
int inRoom;
int player_position;
room * curr_room;
*/

typedef struct server_thread_input {
  int inHall;
  int inRoom;
  int player_position;
  room * curr_room;
  int client_fd;
  //bool inGame;
} server_thread_input;

typedef struct ethread_input {
  int fd;
  int vocation; // 0 is civilian, 1 is police, 2 is killer.
  int alive;
  int position;
} einput;

void shuffle(int *array, size_t n) {    
    srand(time(NULL));
    if (n > 1) {
        size_t i;
        for (i = 0; i < n; i++) {
            size_t j = rand()%n;
            int t = array[j];
            array[j] = array[i];
            array[i] = t;
        }
    }
}

void write_to_room(room * curr_room, char * line, int size) {
  for(int i = 0; i < 20; i++) {
      int fd = curr_room->playerfd[i];
      if(fd != -1) {
	write(fd, line, size);	
      }
  }
}

int isIn(int tmp, int * array) {
  for(int i = 0; i < 20; i++) {
    if(array[i] == tmp) return 1;
  }
  return 0;
}

void * processGame(void * args) {
  printf("new game\n");
  room* curr_room = (room*)args;

  int n = curr_room->curr_num_user;
  int num_of_killers = n/5;
  int num_of_polices = n/5;
  int num_of_civilian = n - num_of_killers - num_of_polices;

  int vocations[n];
  memset(vocations, 0, sizeof(int) * n);
  for(int i = 0; i < num_of_killers; i++) {
	vocations[i] = 2;
	vocations[num_of_killers + i] = 1;	
  }

  shuffle(vocations, (size_t)n);
  shuffle(vocations, (size_t)n);

  struct epoll_event event;  
  int epfd = epoll_create(1);

  int players[n];
  int living[20];
  int killers[num_of_killers];
  int polices[num_of_polices];
  einput * info[n];

  int i = 0;
  int j = 0;
  int k = 0;
  for(i = 0; i < n; i++) {
    	if(vocations[i] == 1) {
	    polices[k] = i;
	    k++; 
    	}
	if(vocations[i] == 2) {
	    killers[j] = i;
	    j++;
	}
  }
  j = 0;
  sleep(1);
  einput * info_array[20];
  for(i = 0; i < 20; i++) {
      int fd = curr_room->playerfd[i];
      living[i] = 0;
      info_array[i] = NULL;
      if(fd != -1) {
	  players[j] = fd;
	  living[i] = 1;

	  einput * tmp = malloc(sizeof(einput));
          info[j] = tmp;
	  tmp->fd = fd;
	  tmp->vocation = vocations[j]; 
	  tmp->alive = 1;
	  tmp->position = i;
	  info_array[i] = tmp;          

          event.events = EPOLLIN;  // EPOLLIN==read, EPOLLOUT==write
          event.data.ptr = tmp;
          epoll_ctl(epfd, EPOLL_CTL_ADD, fd, &event);
	
	  char buffer[500];
          memset(buffer, 0, 500);
          int blen = snprintf(buffer, 50, "VOCA%d", vocations[j]);
	  if(vocations[j] == 1) {
		char tmp[20];
		char * c = tmp;
		memset(tmp, 0, 20);
		for(int k = 0; k < num_of_polices; k++) {
		    int len = snprintf(c, 4, "%d", polices[k]+1);
		    //printf("p %d\n", polices[k] + 1);
		    c+=(len+1);
		}
		memcpy(buffer+blen+1, tmp, 20);
	  }
	  if(vocations[j] == 2) {
		char tmp[20];
                char * c = tmp;
                memset(tmp, 0, 20);
                for(k = 0; k < num_of_killers; k++) {
                    int len = snprintf(c, 4, "%d", killers[k]+1);
                    c+=(len+1);
		    //printf("k %d\n", killers[k]+1);
                }
                memcpy(buffer+blen+1, tmp, 20);
	  } 
	  
          int abc = write(fd, buffer, 70);
	  write(fd, "\n", 1);
          j++;
      }
  }

  int round = 1;
  long time_per_round = 1000 * n * 4 * 2;
  char * buffer = malloc(500);
  size_t nm = 500; 
 
  int killers_vote[20];
  int polices_vote[20];
  int execute_vote[20];

  while(1) {
	memset(killers_vote, 0, sizeof(int) * 20);
	memset(polices_vote, 0, sizeof(int) * 20);
	memset(execute_vote, 0, sizeof(int) * 20);
	long begin_of_curr_round = time(NULL) * 1000;
	long curr_round_time = time_per_round;
	write_to_room(curr_room, "NT\n", 3);	
	while(1) {
	    printf("epoll waiting\n");
	    int fd_ready = epoll_wait(epfd, &event, 1, curr_round_time);
	    printf("epoll finished waiting\n");
	    einput * player_info = (einput*) event.data.ptr;
	    long curr_time = time(NULL) * 1000;
	    curr_round_time = time_per_round - (curr_time - begin_of_curr_round);
	    if(fd_ready == -1) printf("epoll error!\n");
	    if(player_info->alive == 0) continue;
	    if(fd_ready == 0 || curr_round_time <= 0) {
		printf("time up!\n"); 
		break;
	    }
	    else {
		FILE * fd = fdopen(((einput*)event.data.ptr)->fd, "r");
		//printf("getting line\n");
		int rt = getline(&buffer, &nm, fd);
		printf("epoll : %s", buffer);
		//fclose(fd);
		if(rt <= 0) {
		    fclose(fd);
		    printf("disconnection!\n"); 
		}
	 	else {
		    fd_ready = ((einput*)event.data.ptr)->fd;
		    if(strncmp(buffer, "/team", 5) == 0) {
			char * chat = buffer + 6;
                        char chat_line[400];
                        memset(chat_line, 0, 400);
                        int len = snprintf(chat_line, 400, "%s %s: %s\n", "/team", curr_room->player_names[player_info->position], chat);
			if(player_info->vocation == 1) {
			    for(i = 0; i < n/5; i++) {
				write(curr_room->playerfd[polices[i]], chat_line, len);
			    }
			}
			else if(player_info->vocation == 2) {
			    for(i = 0; i < n/5; i++) {
				printf("killer: %d\n", killers[i]);
                                write(curr_room->playerfd[killers[i]], chat_line, len);
                            }
			}
		    }
		    else if(strncmp(buffer, "PLIF", 4) == 0) {
    			char * rt = calloc(460 * sizeof(char) + 8, 1);
    			char * tmp;
			strncpy(rt, "PLIF", 4);
    			for(j = 0; j < 20; j++) {
        			if(curr_room->playerfd[j] == curr_room->host) 
					break;
    			}
			
    			*(int*)(rt+4) = j;
    			i = 0;
			k = 0;
    			for(tmp = rt+8; tmp < rt+468; tmp+=23) {
        		    if(curr_room->playerfd[i] != -1) {
				*tmp = (char)vocations[k];
				*(tmp+1) = (char)living[i];
				strncpy(tmp+2, curr_room->player_names[i], 21);
				k++;
			    }
			    else {
				*tmp = (char)5;
				*(tmp+1) = (char)5;
			    }
        		    i++;
    			}
			write(fd_ready, rt, 468);
			write(fd_ready, "\n", 1);
			free(rt);
                    }
		    else if(strncmp(buffer, "TIME", 4) == 0) {
			write(fd_ready, "NTTM\n", 5);	
                    }
		    else if(strncmp(buffer, "CKNM", 4) == 0) {
			int vn = 0;
			sscanf(buffer, "CKNM%d", &vn);
                        char chat_line[400]; 
                        int len = snprintf(chat_line, 400, "%s %d %s: %d\n", "PL", player_info->position, curr_room->player_names[player_info->position], vn);
			if(living[vn-1] == 0) {
			    write(fd_ready, "CKDD\n", 5);
			}
			//else if(player_info->vocation == 1) {
			    if(curr_room->playerfd[vn-1] == -1 
						|| info_array[vn-1]->alive == 0) {
				write(fd_ready, "INTA\n", 5);
			    }
			    else {
			        polices_vote[vn-1]++;
                                for(i = 0; i < n/5; i++) {
                                    write(curr_room->playerfd[polices[i]], chat_line, len);
                                }
			    }
                        //}
                    }
		    else if(strncmp(buffer, "KLNM", 4) == 0) {
			int kn = 0;
                        sscanf(buffer, "KLNM%d", &kn);
			printf("kill %d\n", kn);
                        char chat_line[400];
                        int len = snprintf(chat_line, 400, "%s %d %s: %d\n", "KL", player_info->position + 1, curr_room->player_names[player_info->position], kn);
			printf("%s\n", chat_line);
		        if(living[kn] == 0) {
                            write(fd_ready, "KLDD\n", 5);
                        }
                        //if(player_info->vocation == 2) {
			    if(curr_room->playerfd[kn-1] == -1
                                                || info_array[kn-1]->alive == 0) {
                                write(fd_ready, "INTA\n", 5);
                            }
			    else {
			        killers_vote[kn-1]++;
                                for(i = 0; i < n/5; i++) {
                                    write(curr_room->playerfd[killers[i]], chat_line, len);
                                }
			    }
                        //}
                    }
		}
	    }
	}
	int kill = 0;
	int check = 0;
	for(int i = 0; i < 20; i++) {
	    if(polices_vote[check] < polices_vote[i]) check = i;
	    if(killers_vote[kill] < killers_vote[i]) kill = i;
	}

	char sd_line[10];
	if(killers_vote[kill] != 0) {
	    info_array[kill]->alive = 0;
	    living[kill] = 0;
	    write(info_array[kill]->fd, "YD\n", 3);
	    int len = snprintf(sd_line, 10, "DEAD%d %d\n", kill+1, info_array[kill]->vocation);
            write_to_room(curr_room, sd_line, len);
	    if(info_array[kill]->vocation == 1) {
		num_of_polices--;
	    }
	    if(info_array[kill]->vocation == 2) {
		num_of_killers--;
	    }
	}

	else {
	    write_to_room(curr_room, "NODD\n", 5);
	}

	if(polices_vote[check] != 0) {
	    int len = snprintf(sd_line, 10, "CK%d %d\n", check+1, info_array[check]->vocation);
	    for(i = 0; i < n/5; i++) {
	        write(curr_room->playerfd[polices[i]], sd_line, len);
            }
	}
	if(num_of_polices == 0) {
	    write_to_room(curr_room, "KLWI\n", 5);
	    curr_room->isPlaying = 0;
	    for(int i = 0; i < 20; i++) {
		if(curr_room->playerfd[i] != -1) {
		    sem_post(&curr_room->waiting[i]);
		}
	    }
	    pthread_exit(0);
	}
	else if(num_of_killers == 0) {
            write_to_room(curr_room, "PLWI\n", 5);
            curr_room->isPlaying = 0;
            for(int i = 0; i < 20; i++) {
                if(curr_room->playerfd[i] != -1) {
                    sem_post(&curr_room->waiting[i]);
                }
            }
            pthread_exit(0);
        }
	
	begin_of_curr_round = time(NULL) * 1000;
        curr_round_time = time_per_round;
        write_to_room(curr_room, "DT\n", 3);
	while(1) {
            printf("epoll waiting\n");
            int fd_ready = epoll_wait(epfd, &event, 1, curr_round_time);
            printf("epoll finished waiting\n");
            einput * player_info = (einput*) event.data.ptr;
            long curr_time = time(NULL) * 1000;
            curr_round_time = time_per_round - (curr_time - begin_of_curr_round);
	    if(player_info->alive == 0) continue;
            if(fd_ready == -1) printf("epoll error!\n");
            if(fd_ready == 0 || curr_round_time <= 0) {
                printf("time up!\n");
                break;
            }
            else {
                FILE * fd = fdopen(((einput*)event.data.ptr)->fd, "r");
                //printf("getting line\n");
                int rt = getline(&buffer, &nm, fd);
                printf("epoll : %s", buffer);
                //fclose(fd);
                if(rt <= 0) {
                    fclose(fd);
                    printf("disconnection!\n");
                }
		else {
                    fd_ready = ((einput*)event.data.ptr)->fd;
                    if(strncmp(buffer, "/team", 5) == 0) {
                        char * chat = buffer + 6;
                        char chat_line[400];
                        memset(chat_line, 0, 400);
                        int len = snprintf(chat_line, 400, "%s %s: %s\n", "/team", curr_room->player_names[player_info->position], chat);
                        if(player_info->vocation == 1) {
                            for(i = 0; i < n/5; i++) {
                                write(curr_room->playerfd[polices[i]], chat_line, len);
                            }
                        }
                        else if(player_info->vocation == 2) {
                            for(i = 0; i < n/5; i++) {
                                printf("killer: %d\n", killers[i]);
                                write(curr_room->playerfd[killers[i]], chat_line, len);
                            }
                        }
                    }
		    else if(strncmp(buffer, "PLIF", 4) == 0) {
                        char * rt = calloc(460 * sizeof(char) + 8, 1);
                        char * tmp;
                        strncpy(rt, "PLIF", 4);
                        for(j = 0; j < 20; j++) {
                                if(curr_room->playerfd[j] == curr_room->host)
                                        break;
                        }

                        *(int*)(rt+4) = j;
                        i = 0;
                        k = 0;
                        for(tmp = rt+8; tmp < rt+468; tmp+=23) {
                            if(curr_room->playerfd[i] != -1) {
                                *tmp = (char)vocations[k];
                                *(tmp+1) = (char)living[i];
                                strncpy(tmp+2, curr_room->player_names[i], 21);
                                k++;
                            }
                            else {
                                *tmp = (char)5;
                                *(tmp+1) = (char)5;
                            }
                            i++;
                        }
                        write(fd_ready, rt, 468);
                        write(fd_ready, "\n", 1);
                        free(rt);
                    }
		    else if(strncmp(buffer, "TIME", 4) == 0) {
                        write(fd_ready, "DTTM\n", 5);
                    }
                    else if(strncmp(buffer, "VOTE", 4) == 0) {
                        int vn = 0;
                        sscanf(buffer, "VOTE%d", &vn);
                        char chat_line[400];
                        int len = snprintf(chat_line, 400, "%s %d %s: %d\n", "VT", player_info->position, curr_room->player_names[player_info->position], vn);
                        if(living[vn-1] == 0) {
                            write(fd_ready, "VTDD\n", 5);
                        }
                        //else if(player_info->vocation == 1) {
                            if(curr_room->playerfd[vn-1] == -1
                                          || info_array[vn-1]->alive == 0) {
                                write(fd_ready, "INTA\n", 5);
                            }
                            else {
                                execute_vote[vn-1]++;
                                write_to_room(curr_room, chat_line, len);
                            }
                        //}
                    }
		}
	    }
 	}
	int execute = 0;
        for(int i = 0; i < 20; i++) {
            if(execute_vote[execute] < execute_vote[i]) execute = i;
        }

	//char sd_line[10];
        if(execute_vote[execute] != 0) {
            info_array[execute]->alive = 0;
            living[execute] = 0;
            write(info_array[execute]->fd, "YD\n", 3);
            int len = snprintf(sd_line, 10, "DEAD%d %d\n", execute+1, info_array[execute]->vocation);
            write_to_room(curr_room, sd_line, len);
            if(info_array[kill]->vocation == 1) {
                num_of_polices--;
            }
	    if(info_array[kill]->vocation == 2) {
		num_of_killers--;
	    }
        }

        else {
            write_to_room(curr_room, "NOEX\n", 5);
        }
	if(num_of_polices == 0) {
            write_to_room(curr_room, "KLWI\n", 5);
            curr_room->isPlaying = 0;
            for(int i = 0; i < 20; i++) {
                if(curr_room->playerfd[i] != -1) {
                    sem_post(&curr_room->waiting[i]);
                }
            }
            pthread_exit(0);
        }
        else if(num_of_killers == 0) {
            write_to_room(curr_room, "PLWI\n", 5);
            curr_room->isPlaying = 0;
            for(int i = 0; i < 20; i++) {
                if(curr_room->playerfd[i] != -1) {
                    sem_post(&curr_room->waiting[i]);
                }
            }
            pthread_exit(0);
        }

     } 
}

void * processClient(void * args) {

    int * inHall = &((server_thread_input*)args)->inHall;
    int * inRoom = &((server_thread_input*)args)->inRoom;
    int * player_position = &((server_thread_input*)args)->player_position;
    room ** curr_room = &((server_thread_input*)args)->curr_room;
    int client_fd = ((server_thread_input*)args)->client_fd;
    //bool * inGame = &((server_thread_input*)args)->inGame;

    *inHall = -1;
    *inRoom = -1;
    welcomeinfo uinfo;
    read(client_fd, &uinfo, sizeof(welcomeinfo));
    welcomeinfo * tmp = &uinfo;

    printf("processing %s\n", uinfo.name);

    /*
    if(tmp->purpose == 0) {
        printf("The user wants to quit\n");
    }
    else if(tmp->purpose == 1) {
        printf("The user wants to login\n");
        printf("Name is %s\n", tmp->name);
        printf("Password is %s\n", tmp->password);
    }
    else {
        printf("The user wants to signup\n");
        printf("Name is %s\n", tmp->name);
        printf("Password is %s\n", tmp->password);
    }
    */

    if(uinfo.purpose == 1) { //login
	/*
	user * usr = findUser(database, tmp->name);
	//char * usr_password = findUserPassword(database, tmp->name);
	if(usr) printf("password: %s\n", usr->password);
	if(!usr || strcmp(usr->password, tmp->password)) {
	    write(client_fd, "FAIL", 4);
	    close(client_fd);
	    pthread_exit(NULL);
	}
	*/
	int li = userLogin(database, tmp->name, tmp->password);
	if(li == 1 || li == 2) {
	    write(client_fd, "FAIL", 4);
            close(client_fd);
            pthread_exit(NULL);
 	}
	else {
	    srand (time(NULL));
  	    int random_number = rand();
	    char buffer[4*sizeof(char) + sizeof(int)];
	    strcpy(buffer, "SUCC");
	    int * p = (int*)(buffer + 4);
	    *p = random_number;
	    write(client_fd, buffer, 4*sizeof(char) + sizeof(int));
	}
    }
    else if(uinfo.purpose == 2) { //sign up
	user usr;
	strcpy(usr.name, tmp->name);
	strcpy(usr.password, tmp->password);
	printf("name is %s\n", usr.name);
	printf("password is %s\n", usr.password);
	int add = addUser(database, &usr);
        if(add == -1) {
            write(client_fd, "FAIL", 4);
            close(client_fd);
            pthread_exit(NULL);
        }
        else {
            srand (time(NULL));
            int random_number = rand();
            char buffer[4*sizeof(char) + sizeof(int)];
            strcpy(buffer, "SUCC");
            int * p = (int *)(buffer + 4);
            *p = random_number;
            write(client_fd, buffer, 4*sizeof(char) + sizeof(int));
	    printf("The random number is %d\n", random_number);
        }	
    }
    else {
	write(client_fd, "FAIL", 4);
	close(client_fd);
	pthread_exit(NULL);
    }
    
    char * buffer = malloc(500);
    size_t nm = 500;
    FILE* fp = fdopen(client_fd, "r");
    int nr = 0;
    while(1) {
	/*
        if((*curr_room) && (*curr_room)->isPlaying) {
            sem_wait(&(*curr_room)->waiting[*player_position]);
        }
	*/

	memset(buffer, 0, nr);
	//int nr = read(client_fd, buffer, 500);
	nr = getline(&buffer, &nm, fp);
	if(nr <= 0) pthread_exit(NULL);
	printf("thread: %s", buffer);	
	if(*inHall == -1 && *inRoom == -1) {
		if(strncmp(buffer, "LBIF", 4) == 0) {
		    int num = hall->curr_num_user;
		    snprintf(buffer, 50, "LBIF%d %d\n", 1, num);
		    write(client_fd, buffer, strlen(buffer));
	 	}
		else if(strncmp(buffer, "ENLB", 4) == 0) {
		    int num = 0;
		    sscanf(buffer, "ENLB%d", &num);
		    if(num != 1) {
			write(client_fd, "INVDLBN\n", 8);
		    }
		    else {
			int en = enter_lobby(hall, client_fd);
			if(en) write(client_fd, "LBFL\n", 5);
			else {
			    write(client_fd, "LBSS\n", 5);
			}
			*inHall = 1;
		    }
	 	}	
		else if(strncmp(buffer, "EXIT", 4) == 0) {
		    pthread_exit(0);
		}
	}
	else if(*inHall != -1 && *inRoom == -1) {
	    if(strncmp(buffer, "RMIF", 4) == 0) {
		char room_info_bytes[200];
		memset(room_info_bytes, 0, 200);
                int * room_info = getLobbyinfo(hall);
		strncpy(room_info_bytes, "RMIF", 4);
		memcpy(room_info_bytes+4, room_info, 20 * sizeof(int));
                write(client_fd, room_info_bytes, 4 + 20*sizeof(int));
	  	write(client_fd, "\n", 1);
		free(room_info);
            }
            else if(strncmp(buffer, "ENRM", 4) == 0) {
                int num = 0;
                sscanf(buffer, "ENRM%d", &num);
                if(num < 1 || num > 20) {
                    write(client_fd, "INVDRMN\n", 8);
                }
                else {
                    int en = enter_room(hall, num-1, client_fd, tmp->name);
                    if(en == -2 || en == -1) write(client_fd, "RMFL\n", 5);
		    else if(en == -3) {
			write(client_fd, "RMPL\n", 5);
		    }
                    else {
			*player_position = en;			    
			*curr_room = &hall->rooms[num-1];
                        write(client_fd, "RMSS\n", 5);
                    }
                    *inRoom = num;
                 }
            }
            else if(strncmp(buffer, "EXIT", 4) == 0) {
                 *inHall = -1;
		 write(client_fd, "EXSC\n", 5);
            }
        }
        else if(*inHall != -1 && *inRoom != -1) { // in room now
	    if((*curr_room)->isPlaying) {
		printf("thread go waiting!\n");
		sem_wait(&(*curr_room)->waiting[*player_position]);	
		printf("thread finish waiting!\n");
	    }
	    else {
	        if(strncmp(buffer, "PLIF", 4) == 0) {
		    char room_info_bytes[500];
                    memset(room_info_bytes, 0, 500);
                    char * room_in = getRoominfo(hall, *inRoom-1);
		
                    strncpy(room_info_bytes, "PLIF", 4);
                    memcpy(room_info_bytes+4, room_in, 424 * sizeof(char));
                    write(client_fd, room_info_bytes, 450);
		    write(client_fd, "\n", 1);
                    free(room_in);	
	        }
	        else if(strncmp(buffer, "READ", 4) == 0) {
		    (*curr_room)->ready[*player_position] = 1;
		    write(client_fd, "RDSC\n", 5);
	        }
	        else if(strncmp(buffer, "UNRE", 4) == 0) {
		    (*curr_room)->ready[*player_position] = 0;
		    write(client_fd, "UNSC\n", 5);
	        }
		else if(strncmp(buffer, "GMBG", 4) == 0) {
		    sem_wait(&(*curr_room)->waiting[*player_position]);
		}
	        else if(strncmp(buffer, "BEGI", 4) == 0) {
		    if((*curr_room)->host != client_fd) {
			write(client_fd, "NHST\n", 5);
		    }
		    else if((*curr_room)->curr_num_user < 5){
			write(client_fd, "NUIN\n", 5);
		    }
		    else {
			(*curr_room)->isPlaying = 1;
			for(int i = 0; i < 20; i++) {
			    if((*curr_room)->playerfd[i] != -1) {
				sem_init(&(*curr_room)->waiting[*player_position], 0, 0);
		                write((*curr_room)->playerfd[i], "GMBG\n", 5);	
			    }
			}
			pthread_t game;	
			pthread_create(&game, NULL, processGame, *curr_room);
			sem_wait(&(*curr_room)->waiting[*player_position]);
			pthread_join(game, NULL);
		    }
	        }
	        else if(strncmp(buffer, "EXIT", 4) == 0) {
		    exit_room(hall, *inRoom-1, client_fd);
		    *inRoom = -1;
		    *curr_room = NULL;
		    *player_position = -1;
		    write(client_fd, "EXSC\n", 5);
	        }
	        else if(strncmp(buffer, "/all ", 5) == 0) {
		    char * chat = buffer + 5;
	  	    char chat_line[400];
		    memset(chat_line, 0, 400);
                    int n = snprintf(chat_line, 400, "%s %s: %s\n", "/all", uinfo.name, chat);
		    for(int i = 0; i < 20; i++) {
		        if((*curr_room)->playerfd[i] != -1) {
			   write((*curr_room)->playerfd[i], chat_line, n);
		        }	    
		    }
	        }
	    }
        }
	else {
            printf("error occured!\n");
            close(client_fd);
            pthread_exit(0);
        }
    } 
}
#endif
