#ifndef _PROCESSSERVER_
#define _PROCESSSERVER_

#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <stdbool.h>
#include <semaphore.h>

#include "game_window.h" 
#include "welcome.c"

//extern int sock_fd;

//int input = 1;

//int inHall;
//int inRoom;

//int tryHall;
//int tryRoom;

//bool done;
//sem_t sem;

typedef struct tin {
    int inHall;
    int inRoom;

    int tryHall;
    int tryRoom;

    bool done;
    sem_t sem;

    int sock_fd;
    bool inGame;

    int mates[4];
    int vocation;
  
    int time;
} client_thread_input;

void* processServerIn(void* arg) {

    int * inHall = &((client_thread_input*)arg)->inHall;
    int * inRoom = &((client_thread_input*)arg)->inRoom;

    int * tryHall = &((client_thread_input*)arg)->tryHall;
    int * tryRoom = &((client_thread_input*)arg)->tryRoom;

    bool * done = &((client_thread_input*)arg)->done;
    sem_t * sem = &((client_thread_input*)arg)->sem;
    bool * inGame = &((client_thread_input*)arg)->inGame;

    int sock_fd = ((client_thread_input*)arg)->sock_fd;
    int * mates = ((client_thread_input*)arg)->mates;
    int * vocation = &((client_thread_input*)arg)->vocation;

    *inHall = -1;
    *inRoom = -1;
    //sem_init(&sem, 0, 0);

    printf("You are online now :-)\n");

    char * buffer = malloc(500);
    FILE * fd = fdopen(sock_fd, "r");
    size_t nm = 500;
    int n = 0;
    while(1) {
	memset(buffer, 0, n);
	//int n = read(sock_fd, buffer, 500);
	n = getline(&buffer, &nm, fd);
	//printf("receiving %d: %s\n",n, buffer);
	if(*done == 1 || n <= 0) {
	    *done = 1;
            pthread_exit(0);
        }
	if(*inHall == -1 && *inRoom == -1) {
	    if(strncmp(buffer, "LBIF", 4) == 0) {
		int hall_num = 0;
		int curr_player_num = 0;
		sscanf(buffer, "LBIF%d %d", &hall_num, &curr_player_num);
		for(int i = 0; i < hall_num; i++) {
		    printf("Hall %d : %d players\n", i+1, curr_player_num);
		}
		sem_post(sem);
	    }
	    else if(strncmp(buffer, "INVDLBN", 7) == 0) {
		printf("Invalid lobby number!\n");
		sem_post(sem);
	    }  
	    else if(strncmp(buffer, "LBFL", 4) == 0) {
		printf("The lobby number %d is full now!\n", *tryHall);
		sem_post(sem);
	    }
	    else if(strncmp(buffer, "LBSS", 4) == 0) {
		printf("You are in lobby %d now\n", *tryHall);
		*inHall = *tryHall;
		sem_post(sem);
	    }
	    else {
		printf("receiving undefined response!\n");
		sem_post(sem);
	    }
	}
	else if(*inHall != -1 && *inRoom == -1) {
	    if(strncmp(buffer, "RMIF", 4) == 0) {
                int * curr = (int*)(buffer + 4);
                for(int i = 0; i < 20; i++) {
                    printf("room %d : %d players\n", i+1, *curr);
		    curr++;
                }
                sem_post(sem);
	    }
	    else if(strncmp(buffer, "INVDRMN", 7) == 0) {
		printf("Invalid room number!\n");
                sem_post(sem);
	    }
	    else if(strncmp(buffer, "RMFL", 4) == 0) {
		printf("The lobby number %d is full now!\n", *tryRoom);
                sem_post(sem);
	    }
	    else if(strncmp(buffer, "RMPL", 4) == 0) {
		printf("The lobby is currently playing!\n");
		sem_post(sem);
	    }
	    else if(strncmp(buffer, "RMSS", 4) == 0) {
		printf("You are in room %d now\n", *tryRoom);
                *inRoom = *tryRoom;
                sem_post(sem);	
	    } 
	    else if(strncmp(buffer, "EXSC", 4) == 0) {
		printf("You just quited hall %d\n", *inHall);
		*inHall = -1;
		sem_post(sem);
            }
	    else {
		printf("receiving undefined response in lobby!\n");
                sem_post(sem);		
	    }  
	}
	else if(*inHall != -1 && *inRoom != -1) { //in room now
	    if(*inGame != 0) {
		//printf("In game now : %s!\n", buffer);
		if(strncmp(buffer, "NT", 2) == 0) {
		    printf("It is night now. Killers and polices are able to do their job!\n");
		}
		if(strncmp(buffer, "DT", 2) == 0) {
                    printf("It is day time now. Go vote to execute someone!\n");
                }

		else if(strncmp(buffer, "VOCA", 4) == 0) {
		    char * tmp = buffer+4;
		    sscanf(tmp, "%d", vocation);
		    for(int i = 0; i < 4; i++) {
			while(*tmp != '\0') tmp++;
			tmp++;
			int p = 0;
			sscanf(tmp, "%d", &p);
			if(p == 0) break;
			mates[i] = p;
		    }
		    if(*vocation == 0) 
                        printf("You are civilian. You must help police to find out who the killers are, and execute them!\n");

                    else if(*vocation == 1) {
                        printf("You are police. Every night the police can check one person's identity, go vote for the one you want to check.\n");
			printf("The following players are your companions:\n");
			for(int i = 0; i < 4; i++) {
			    if(mates[i] != 0) {
				printf("%d ", mates[i]);
			    }
			}
			printf("\n");
			printf("You must cooperate with them to win this game!\n");	
		    }

                    else if(*vocation == 2) {
                        printf("You are killer. Every night the killer can kill one person, go vote for the one you want to kill!\n");
			printf("The following players are your companions:\n");
                        for(int i = 0; i < 4; i++) {
                            if(mates[i] != 0) {
                                printf("%d ", mates[i]);
                            }
                        }
			printf("\n");
                        printf("You must cooperate with them to win this game!\n"); 
                    }
		    
		}
		

		else if(strncmp(buffer, "/team", 4) == 0){
                    char * chat_line = buffer + 6;
                    printf("(team)%s\n", chat_line);
                }
                else if(strncmp(buffer, "PLIF", 4) == 0) {
		    int host = *(int*)(buffer+4);
                    char * curr = buffer + 8;
                    int i = 0;
                    for(char * tmp = curr;  tmp < curr+460; tmp += 23) {
			if(*tmp == (char)5 || *(tmp+1) == (char)5) {
			    i++;
			}
			else {
			    int v = (int)*tmp;
			    int liv = (int)*(tmp+1);
			    if(v == *vocation) {
			        if(v == 1)printf("(police)");
			        if(v == 2)printf("(killer)");
				else printf("        ");
			    }
			    else printf("\t");
                            if(i != host) printf("player %d : %s     ", i+1, tmp+2);
                            else printf("player %d : %s(host)", i+1, tmp+2);
			
			    if(liv == 1) printf("\t(alive)\n");
			    else printf("\t(dead)\n");
                            i++;
			}
                    }
                }
                else if(strncmp(buffer, "NTTM", 4) == 0) {
		    printf("It is night time now.\n");
                }
		else if(strncmp(buffer, "DTTM", 4) == 0) {
                    printf("It is day time now.\n");
                }
		else if(strncmp(buffer, "KLDD", 4) == 0) {
		    printf("You cannot kill someone already dead!\n");
		}
		else if(strncmp(buffer, "CKDD", 4) == 0) {
		    printf("You cannot investigate someone already dead!\n");
		}
		else if(strncmp(buffer, "VTDD", 4) == 0) { 
                    printf("You cannot execute someone already dead!\n");
                }
                else if(strncmp(buffer, "PL ", 3) == 0) {
		    char name[21];
		    int np = 0;
		    int vn = -1;
		    sscanf(buffer+3, "%d %s: %d\n", &np, name, &vn);
		    printf("%s(%d) votes to check %s", name, np, buffer+8);
                }
		else if(strncmp(buffer, "KL ", 3) == 0) {
		    char name[21];
                    int np = 0;
                    int vn = -1;
		    //printf("buffer : %s", buffer);
                    sscanf(buffer+3, "%d %s: %d\n", &np, name, &vn);
                    printf("%s(%d) votes to kill %s", name, np, buffer+8);
		}
		else if(strncmp(buffer, "VT ", 3) == 0) {
                    char name[21];
                    int np = 0;
                    int vn = -1;
                    sscanf(buffer+3, "%d %s: %d\n", &np, name, &vn);
                    printf("%s(%d) votes to execute %s", name, np, buffer+8);
                }
		else if(strncmp(buffer, "INTA", 4) == 0) {
		    printf("Invalid choice number!\n");
		}
		else if(strncmp(buffer, "YD", 2) == 0) {
		    printf("You are killed by the killer(s) last night : (\n");
		}
		else if(strncmp(buffer, "DEAD", 4) == 0) {
		    int dd_num = 0;
		    int voc = 0;
		    sscanf(buffer, "DEAD%d %d\n", &dd_num, &voc);
		    printf("Player %d was killed last night! ", dd_num);
		    if(voc == 0) printf("He(She)'s a civilian.\n");
		    else if(voc == 1) printf("He(She)'s a police.\n");
		    else printf("He(She)'s a killer.\n"); 
		}
	 	else if(strncmp(buffer, "NODD", 4) == 0) {
		    printf("Killers didn't kill anyone last night!\n");
		}
		else if(strncmp(buffer, "NOEX", 4) == 0) {
                    printf("No one is executed today!\n");
                }
		else if(strncmp(buffer, "CK", 2) == 0) {
		    int ck_num = 0;
		    int result = 0;
		    sscanf(buffer, "CK%d %d", &ck_num, &result); 
		    if(result == 0)printf("Player %d is a civilian\n", ck_num);
		    else if(result == 2)
			printf("Player %d is a killer!\n", ck_num);
		    else if(result == 1)
			printf("Player %d is a police, why would you even check your compainion's identity?\n", ck_num);
		}
		else if(strncmp(buffer, "KLWI", 4) == 0) {
		    *inGame = 0;
		    printf("The game is ended now. Killers are winners!\n");
		    printf("-----------------------------------------------\n");
		    printf("You are in room %d now\n", *inRoom);
		}
		else if(strncmp(buffer, "PLWI", 4) == 0) {
                    *inGame = 0;
                    printf("The game is ended now. Civilians and Polices are winners!\n");
                    printf("-----------------------------------------------\n");
		    printf("You are in room %d now\n", *inRoom);
                }
		
            }
	    else {
	    	if(strncmp(buffer, "PLIF", 4) == 0) {
		    int host = *(int*)(buffer+4);
                    char * curr = buffer + 8;
		    int i = 0;
                    for(char * tmp = curr;  tmp < curr+420; tmp += 21) {
                        if(i != host) printf("player %d : %s\n", i+1, tmp);
		        else printf("player %d : %s(host)\n", i+1, tmp);
                        i++;
                    }
                    sem_post(sem);
                }
		else if(strncmp(buffer, "/all", 4) == 0) {
		    printf("%s", buffer+5);
		}
	        else if(strncmp(buffer, "RDSC", 4) == 0) {
		    printf("You are ready to play now!\n");
		    sem_post(sem);
	        }
	        else if(strncmp(buffer, "UNSC", 4) == 0) {
		    printf("You are now not ready to play : (\n");
		    sem_post(sem);
	        }
		else if(strncmp(buffer, "NHST", 4) == 0) {
		    printf("Only host could start an game, and you are not the host of this room!\n");		    
                    sem_post(sem);
                }
		else if(strncmp(buffer, "NUIN", 4) == 0) {
		    printf("There must be at least 5 players in order to start a game!\n");
		    sem_post(sem);
		}
	        else if(strncmp(buffer, "GMBG", 4) == 0) {
		    write(sock_fd, "123\n", 4);
		    *inGame = 1;
		    printf("\033[2J\033[1;1H");
		    printf("3\n");
		    sleep(1);
		    printf("2\n");
                    sleep(1);
		    printf("1\n");
                    sleep(1);
		    printf("The game has begun now\n");
		    sem_post(sem);
	        } 
	        else if(strncmp(buffer, "EXSC", 4) == 0) {
		    *inRoom = -1;
		    sem_post(sem);
	        }
            }	
	}
    }
}

void* processServerOut(void* arg) {
    int * inHall = &((client_thread_input*)arg)->inHall;
    int * inRoom = &((client_thread_input*)arg)->inRoom;

    int * tryHall = &((client_thread_input*)arg)->tryHall;
    int * tryRoom = &((client_thread_input*)arg)->tryRoom;

    bool * done = &((client_thread_input*)arg)->done;
    sem_t * sem = &((client_thread_input*)arg)->sem;

    int sock_fd = ((client_thread_input*)arg)->sock_fd;
    bool * inGame = &((client_thread_input*)arg)->inGame;

    int * mates = ((client_thread_input*)arg)->mates;
    int * vocation = &((client_thread_input*)arg)->vocation;

    int * time = &((client_thread_input*)arg)->time;

    char * line = NULL;
    size_t n = 0;
    while(1) {
	if(*done == 1) pthread_exit(0);
	getline(&line, &n, stdin);
	//printf("inputing : %s", line);
	//line[strlen(line)-1] = '\0';
	if(*inHall == -1 && *inRoom == -1) {
	    if(strncmp(line, "ls", 2) == 0) {
		write(sock_fd, "LBIF\n", 5);	
		//sem_wait(&sem);
	    }
	    else if(strncmp(line, "enter", 5) == 0) {
		char buffer[100];
		int lobby_num = 0;
		sscanf(line, "enter %d\n", &lobby_num);
		if(lobby_num < 1) printf("Invalid lobby number!\n");
		else {
		    int n = snprintf(buffer, 100, "ENLB%d\n", lobby_num);
		    *tryHall = lobby_num;
		    write(sock_fd, buffer, n);
		    sem_wait(sem);	
		}
            }
	    else if(strncmp(line, "quit", 4) == 0) {
		write(sock_fd, "EXIT\n", 5);
		*done = 1;
		pthread_exit(0);
	    }
	    else if(strncmp(line, "help", 4) == 0) {
		printf("Three valid commands are listed below\n");
            	printf("\tls : ask for lobby infomation\n");
            	printf("\tenter [# of lobby] : enter a lobby\n");
            	printf("\tquit : leave killer's Game\n");
	    }
	    else {
		printf("Invalid command! Please type \"help\" for asistance\n");
	    }	   
	}
	else if(*inHall != -1 && *inRoom == -1) {
	    if(strncmp(line, "ls", 2) == 0) {
		write(sock_fd, "RMIF\n", 5);
                sem_wait(sem);
            }
            else if(strncmp(line, "enter", 5) == 0) {
		char buffer[100];
                int room_num = 0;
                sscanf(line, "enter %d\n", &room_num); 
                if(room_num < 1 || room_num > 20) 
			printf("invalid room number!\n");
                else {
                    int n = snprintf(buffer, 100, "ENRM%d\n", room_num);
                    *tryRoom = room_num;
                    write(sock_fd, buffer, n);
                    sem_wait(sem);
                }	
            }
            else if(strncmp(line, "quit", 4) == 0) {
		write(sock_fd, "EXIT\n", 5);
                *inHall = -1;
                sem_wait(sem);
            }
	    else if(strncmp(line, "help", 4) == 0) {
                printf("Three valid commands are listed below\n");
                printf("\tls : ask for room infomation\n");
                printf("\tenter [# of room] : enter a room\n");
                printf("\tquit : leave current lobby\n");
            }
            else {
		printf("Invalid command! Please type \"help\" for asistance\n");
            }
	}
	else if(*inHall != -1 && *inRoom != -1) { //in Room
 	    if(*inGame) {
		if(strncmp(line, "/all", 4) == 0) {
		    if(*time == 0) {
		  	printf("You cannot talk to all players during night time\n");
		    }
		    else {
			write(sock_fd, line, strlen(line)); 
		    }    
		}
		else if(strncmp(line, "/team", 5) == 0) {
		    if(*vocation == 0) {
			printf("As a civilian, you have no team!\n");
		    }
		    else write(sock_fd, line, strlen(line));
		}
		else if(strncmp(line, "/ls", 3) == 0) {
		    write(sock_fd, "PLIF\n", 5);
		}
		else if(strncmp(line, "/time", 5) == 0) {
		   write(sock_fd, "TIME\n", 5);
		} 
		else if(strncmp(line, "/check", 6) == 0) {
		    if(*vocation != 1) {
			printf("Only a policy can check someone!\n");
		    }
		    else {
		        char buffer[100];
                        int check_num = 0;
                        sscanf(line, "/check %d", &check_num);
                        if(check_num < 1 || check_num > 20)
                            printf("invalid check number!\n");
                        else {
                            int n = snprintf(buffer, 100, "CKNM%d\n", check_num);
                            write(sock_fd, buffer, n);
                        }
		    }
		}	
		else if(strncmp(line, "/kill", 5) == 0) {
		    if(*vocation != 2) {
                        printf("Only a killer can kill someone!\n");
                    }
		    else {   
		        char buffer[100];
                        int kill_num = 0;
                        sscanf(line, "/kill %d", &kill_num);
                        if(kill_num < 1 || kill_num > 20)
                            printf("invalid kill number!\n");
                        else {
                            int n = snprintf(buffer, 100, "KLNM%d\n", kill_num);
                            write(sock_fd, buffer, n);
                        }
		    }
		}
		else if(strncmp(line, "/vote", 5) == 0) {
		    char buffer[100];
                    int vote_num = 0;
                    sscanf(line, "/vote %d", &vote_num);
                    if(vote_num < 1 || vote_num > 20)
                        printf("invalid vote number!\n");
                    else {
                        int n = snprintf(buffer, 100, "VOTE%d\n", vote_num);
                        write(sock_fd, buffer, n);
                    }
		}
		else if(strncmp(line, "/help", 5) == 0) {
		    printf("Three valid commands are listed below\n");
                    printf("\t/all [blablabla...]: talk to all players\n");
                    printf("\t/team : talk to companions, only works for killers and police\n");
		    printf("\t/ls : list all the players' status\n");
		    printf("\t/time : get the current time (night or day) in game\n");
		    printf("\t/check [num] : check [num]'th player' identity, only works for polices\n");
		    printf("\t/kill [num] : kill [num]'th player, only works for killers\n");
		    printf("\t/vote [num] : vote to execute [num]th player during the voting process on day time\n");	
		}
		else {
		    printf("Invalid command! Please type \"/help\" for asistance\n");
		}
	    }
	    else {
            	if(strncmp(line, "/c", 2) == 0) {
                    char * command = line + 3;
		    printf("command is :%s\n", command);
		    if(strncmp(command, "ls", 2) == 0) {
                        write(sock_fd, "PLIF\n", 5);
                        sem_wait(sem);
            	    }
	 	    else if(strncmp(command, "ready", 5) == 0) {
		        write(sock_fd, "READ\n", 5);
		        sem_wait(sem);
		    }
		    else if(strncmp(command, "undo ready", 10) == 0) {
		        write(sock_fd, "UNRE\n", 5); 
		        sem_wait(sem);  
		    }
		    else if(strncmp(command, "begin", 5) == 0) {
		    	write(sock_fd, "BEGI\n", 5);
		    	sem_wait(sem);
		    }
		    else if(strncmp(command, "quit", 4) == 0) {
                    	write(sock_fd, "EXIT\n", 5);
                    	sem_wait(sem);
            	    }
                }
	        else if(strncmp(line, "/all ", 5) == 0) {
		    write(sock_fd, line, strlen(line));
	        }
                else if(strncmp(line, "help", 4) == 0) {
                    printf("Six valid commands are listed below\n");	
                    printf("\t/c ls : ask for player infomation\n");
		    printf("\t/c ready : you are ready to game\n");
                    printf("\t/c undo ready : you are not ready to game\n");
		    printf("\t/c begin : begin the game(only effective if you are the host of current room)\n");
                    printf("\t/c quit : leave current room\n");
		    printf("\t/all [blablabla...] : talk with other players\n");
               }
               else {
                    printf("Invalid command! Please type \"help\" for asistance\n");
               }
	   }
	}
	else {
	    printf("error occured!\n");
	    write(sock_fd, "EXIT\0", 5);
	    close(sock_fd);
	    *done = 1;
	    pthread_exit(0);
	}
	free(line);
	line = NULL;
	n = 0;
    }
}

#endif
