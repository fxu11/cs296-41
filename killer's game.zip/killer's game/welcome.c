#ifndef _WELCOME_
#define _WELCOME_

#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

int isNumberOrAlpha(char c) {
    if( (c >= 48 && c <= 57) || (c >= 65 && c <= 90) || (c >= 97 && c <=122)) {
	return 1;
    }
    else return 0;
}

int isAtOrDot(char c) {
    if(c == 64 || c == 46) {
	return 1;
    }
    else return 0;
}

int nameIsValid(char * name) {
    for(int i = 0; i < 20; i++) {
	if(name[i] == 0) break;
	if(!isNumberOrAlpha(name[i]) && !isAtOrDot(name[i])) 
		return 0;
    }   
    return 1;
}

int passwordIsValid(char * password) {
    for(int i = 0; i < 20; i++) {
	if(password[i] == 0) break;
        if(!isNumberOrAlpha(password[i])) 
		return 0;
    }
    return 1;
}

typedef struct Logininfo {
    int purpose; // 0 means quit; 1 means log in; 2 means sign up
    char name[21];
    char password[21];
} welcomeinfo;

void clearstdin() {
    int flags;
    char c[10];
    printf("clearing\n");
    while(fgets(c, 10, stdin)){printf("%c", c);}
}

struct Logininfo * getInfo() {
  char * name = NULL;
  char * password = NULL;
  size_t len = 0;

  printf("Please input your account name\n");
  getline(&name, &len, stdin);
  name[strlen(name)-1] = '\0';

  if(strlen(name) <= 21 && nameIsValid(name)) {
      	printf("Please input your password\n");
	len = 0;
      	getline(&password, &len, stdin);
	password[strlen(password)-1] = '\0';	

	if(strlen(password) <= 21 && passwordIsValid(password)) {
	    welcomeinfo * lg = malloc(sizeof(welcomeinfo));
	    strcpy(lg->name, name);
	    strcpy(lg->password, password);
	    free(name);
	    free(password);
	    return lg;
	}
	else {
	    printf("Invalid password! The password can only be consist of numbers and letters!\n");
	    free(name);
	    free(password);
	    return NULL;
	}
  }
  else {
	printf("Invalid user name! The user name can only be consist of numbers, letters, @s and dots!\n");
	free(name);
	return NULL;
  }
}

welcomeinfo * welcome() {
    char buffer[128];
    memset(buffer, 0, 128);
    printf("\033[2J\033[1;1H");
    printf("Welcome to Killer's game!\n");
    while(1) {
	printf("Do you want to create an account, sign in, or quit?\n");
        fgets(buffer, 128, stdin);
        if(strcmp(buffer, "sign in\n") == 0) {
	     welcomeinfo * lg = getInfo();
	     if(!lg) continue;
	     lg->purpose = 1;
	     return lg;
        }
        else if(strcmp(buffer, "create an account\n") == 0) {
	    welcomeinfo * lg = getInfo();
	    if(!lg) continue;
	    lg->purpose = 2;
	    return lg;
        }
        else if(strcmp(buffer, "quit\n") == 0) {
	    welcomeinfo * lg = calloc(sizeof(welcomeinfo), 1);
	    return lg;
        }
	else if(strcmp(buffer, "help\n") == 0) {
	    printf("All three valid commands are listed below\n");
	    printf("\tsign in : ask for logging in your account\n");
	    printf("\tcreat an account : this will lead you to the sign up interface\n");
	    printf("\tquit : leave killer's Game\n");
	}
        else {
	    printf("Invalid command! Please type \"help\" for asistance\n");
        }
        memset(buffer, 0, 128);
    }
    return 0;
}
#endif
