#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include "userDatabase.c"

char * users[] = { "fxu1", "fxu2" , "fxu3" , "fxu4", "fxu5", "fxu6", "fxu7", 
			"fxu8", "fxu9", "fxua", "fxub", "fxuc", "fxud"};

int main() {
    userDataBase * database = malloc(sizeof(userDataBase));
    userData_init(database);

    user * tmp = malloc(sizeof(user));

        
    for(int i = 0; i <= 9; i++) {
    	strcpy(tmp->name, users[i]);
   	strcpy(tmp->password, users[i]);
    	tmp->active = 0;
	addUser(database, tmp);

	strcpy(tmp->name, users[i+2]);
        strcpy(tmp->password, users[i+2]);
        tmp->active = 0;
    	addUser(database, tmp); 
    }
    /*
    	strcpy(tmp->name, users[0]);
        strcpy(tmp->password, users[0]);
        tmp->active = 0;
        addUser(database, tmp);

	strcpy(tmp->name, users[2]);
        strcpy(tmp->password, users[2]);
        tmp->active = 0;
        addUser(database, tmp);

	strcpy(tmp->name, users[1]);
        strcpy(tmp->password, users[1]);
        tmp->active = 0;
        addUser(database, tmp);
    */   
    print_all(database);
    write_userData_to_file(database, "ud.txt");
    
    userDataBase * database2 = malloc(sizeof(userDataBase));
    userData_init(database2);
    load_userData_from_file(database2, "ud.txt");
    print_all(database2);
}
