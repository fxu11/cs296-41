#ifndef _ROOM_
#define _ROOM_
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <stdbool.h>
#include <unistd.h>

#include "alloc.c"
typedef struct room {
    bool isPlaying;
    int host;
    int curr_num_user;
    int ready[20];
    int playerfd[20];
    char player_names[20][21];
    sem_t waiting[20];
    pthread_mutex_t room_guard;
} room;

typedef struct lobby {
    room rooms[20];
    pthread_mutex_t lobby_guard;
    int playerfd[400];
    int inRoom[400];
    //char playername[400][20];
    int curr_num_user;
} lobby;

void room_init(room * curr) {
    memset(curr, 0, sizeof(room));
    curr->host = -1;
    for(int i = 0; i < 20; i++) {
	curr->playerfd[i] = -1;
	sem_init(&curr->waiting[i], 0, 0);
    }
    pthread_mutex_init(&curr->room_guard, NULL);
}

void lobby_init(lobby * hall) {
    memset(hall, 0, sizeof(lobby));
    for(int i = 0; i < 19; i++) {
	room_init(&hall->rooms[i]);
    }
    for(int i = 0; i < 400; i++) {
	hall->playerfd[i] = -1;
	hall->inRoom[i] = -1;
    }
    pthread_mutex_init(&hall->lobby_guard, NULL);   
}

int enter_lobby(lobby * hall, int pfd) {
    pthread_mutex_lock(&hall->lobby_guard);
    if(hall->curr_num_user >= 400) {
	printf("No more capacity for this lobby!\n");
	pthread_mutex_unlock(&hall->lobby_guard);
	return 1;
    }
    int i = 0;
    while(hall->playerfd[i] != -1) {i++;}
    hall->playerfd[i] = pfd;
    hall->inRoom[i] = -1;
    hall->curr_num_user++;
    pthread_mutex_unlock(&hall->lobby_guard);
    return 0;
}

int enter_room(lobby * hall, int room_num, int pfd, char * player_name) {
    //pthread_mutex_lock(&hall->lobby_guard);
    int i = 0;
    while(i <= 400 && hall->playerfd[i] != pfd) {i++;}
    if(i == 400) {
        printf("%d not enter the lobby yet\n", pfd);
        //pthread_mutex_unlock(&hall->lobby_guard);
        return -1;
    }
    //pthread_mutex_unlock(&hall->lobby_guard);

    room * curr = &hall->rooms[room_num];
    pthread_mutex_lock(&curr->room_guard);
    if(curr->isPlaying) {
	pthread_mutex_unlock(&curr->room_guard);
	return -3;
    }
    if(curr->curr_num_user == 20) {
	pthread_mutex_unlock(&curr->room_guard);
	printf("The room is full!\n");
	return -1;
    }
    int j = 0;
    while(j <= 20 && curr->playerfd[j] != -1) {j++;}
    //printf("%d\n", j);
    if(j == 20) {
	printf("room full error!\n");
	pthread_mutex_unlock(&curr->room_guard);
	return -2;
    }
    curr->playerfd[j] = pfd;
    strcpy(curr->player_names[j], player_name);
    //printf("%d %d: %s\n", room_num, j, player_name);
    curr->curr_num_user++;
    if(curr->host == -1) curr->host = pfd;
    pthread_mutex_unlock(&curr->room_guard);
    hall->inRoom[i] = room_num;
    return j;
}

int exit_lobby(lobby * hall, int playerfd) {
    pthread_mutex_lock(&hall->lobby_guard);
    int i = 0;
    while(i <= 400 && hall->playerfd[i] != playerfd) {i++;}
    if(i == 400) {
	printf("%d not found\n");
	pthread_mutex_unlock(&hall->lobby_guard);
	return 1;
    }
    int room = hall->inRoom[i]; 
    if(room != -1) {
	printf("%d is still in room %d\n", playerfd, room);
	pthread_mutex_unlock(&hall->lobby_guard);
	return 2;
    }
    hall->playerfd[i] = -1;
    hall->curr_num_user--;
    pthread_mutex_unlock(&hall->lobby_guard);
    return 0;
}

int exit_room(lobby * hall, int room_num, int pfd) {
    //pthread_mutex_lock(&hall->lobby_guard);
    int i = 0;
    while(i <= 400 && hall->playerfd[i] != pfd) {i++;}
    if(i == 400) {
        printf("%d not enter the lobby yet\n", pfd);
        //pthread_mutex_unlock(&hall->lobby_guard);
        return 1;
    }
    //pthread_mutex_unlock(&hall->lobby_guard);

    if(room_num != hall->inRoom[i]) {
	printf("Room number error!\n");
	return 1;
    }
    room * curr = &hall->rooms[room_num];
    pthread_mutex_lock(&curr->room_guard);
    int j = 0;
    while(j <= 20 && curr->playerfd[j] != pfd) {j++;}
    if(j == 20) {
        printf("%d not exist in this room!\n", pfd);
        pthread_mutex_unlock(&curr->room_guard);
        return 2;
    }
    curr->playerfd[j] = -1;
    curr->ready[j] = 0;
    curr->curr_num_user--;
    if(curr->host == pfd) {
	for(j = 0; j < 20; j++) {
	    if(curr->playerfd[j] != -1) break;
	}
	if(j == 20) curr->host = -1;
	else curr->host = curr->playerfd[j];
    }
    pthread_mutex_unlock(&curr->room_guard);
    hall->inRoom[i] = -1;
    return 0;
}

void * getLobbyinfo (lobby * hall) {
    int * rt = mem_alloc(20 * sizeof(int));
    for(int i = 0; i < 20; i++) {
	rt[i] = hall->rooms[i].curr_num_user;
    }
    return rt;
}

void * getRoominfo (lobby * hall, int rnum) {
    //printf("%d\n", rnum);
    room * curr = &hall->rooms[rnum];
    char * rt = calloc(420 * sizeof(char) + 4, 1);
    char * tmp;
    int j;
    for(j = 0; j < 20; j++) {
	if(curr->playerfd[j] == curr->host) break;	
    }

    *(int*)rt = j;
    int i = 0;
    for(tmp = rt+4; tmp < rt+424; tmp+=21) {
	//printf("%d %d: %s\n", rnum, i, curr->player_names[i]);
	if(curr->playerfd[i] != -1) strncpy(tmp, curr->player_names[i], 21);
	i++;
    }
    return rt;
}

#endif
