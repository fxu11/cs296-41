#define _GNU_SOURCE
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <ifaddrs.h>
#include <stdint.h>
#include <pthread.h>

#include "alloc.c"
#include "userDatabase.c"
#include "welcome.c"
#include "processClient.c"
#include "room.c"

userDataBase * database;
lobby * hall;
int main(int argc, char **argv)
{
    database = malloc(sizeof(userDataBase));
    userData_init(database);

    hall = (lobby*)malloc(sizeof(lobby));
    lobby_init(hall);

    int s;
    int sock_fd = socket(AF_INET, SOCK_STREAM, 0);

    struct addrinfo hints, *result;
    memset(&hints, 0, sizeof(struct addrinfo));
    hints.ai_family = AF_INET;
    hints.ai_socktype = SOCK_STREAM;
    hints.ai_flags = AI_PASSIVE;

    s = getaddrinfo(NULL, "1234", &hints, &result);
    if (s != 0) {
            fprintf(stderr, "getaddrinfo: %s\n", gai_strerror(s));
            exit(1);
    }
    /*
    struct ifaddrs * addrs;
    getifaddrs(&addrs);
    struct ifaddrs * tmp = addrs;

    while (tmp) {
        if (tmp->ifa_addr && tmp->ifa_addr->sa_family == AF_INET) {
            struct sockaddr_in *pAddr = (struct sockaddr_in *)tmp->ifa_addr;
            printf("%s: %s\n", tmp->ifa_name, inet_ntoa(pAddr->sin_addr));
        }
        tmp = tmp->ifa_next;
    }

    freeifaddrs(addrs);
    */
    int optval = 1;
    setsockopt(sock_fd, SOL_SOCKET, SO_REUSEPORT, &optval, sizeof(optval));

    if (bind(sock_fd, result->ai_addr, result->ai_addrlen) != 0) {
        perror("bind()");
        exit(1);
    }

    freeaddrinfo(result);
    if (listen(sock_fd, 20) != 0) {
        perror("listen()");
        exit(1);
    }

    struct sockaddr_in *result_addr = (struct sockaddr_in *) result->ai_addr;
    printf("Listening on file descriptor %d, port %d\n", sock_fd, ntohs(result_addr->sin_port));

    while(1) {
    	printf("Waiting for connection...\n");
    	int client_fd = accept(sock_fd, NULL, NULL);
    	printf("Connection made: client_fd=%d\n", client_fd);

    	char buffer[100];
   	int len = read(client_fd, buffer, 5);
	if(strcmp(buffer, "UIUC\0") != 0) {
	    close(client_fd);
	    printf("Wrong response from client, closing fd %d!\n", client_fd);
	    continue;
	}
	write(client_fd, "CHAMPAIGN\0", 10);

	pthread_t not;
	server_thread_input * tmp = calloc(sizeof(server_thread_input), 1);
	tmp->client_fd = client_fd;
	pthread_create(&not, NULL, processClient, tmp);
    }
    return 0;
}
