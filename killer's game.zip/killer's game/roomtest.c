#ifndef _ROOMTEST_
#define _ROOMTEST_
#include <stdio.h>

#include "room.c"

char * p1 = "fxu1";
char * p2 = "fxu2";
char * p3 = "fxu3";
int main() {
    lobby * hall = (lobby*)malloc(sizeof(lobby));
    lobby_init(hall);
    enter_lobby(hall, 1);
    enter_lobby(hall, 2);
    enter_lobby(hall, 3);
    
    enter_room(hall, 0, 1, p1);
    enter_room(hall, 1, 2, p2);
    enter_room(hall, 2, 3, p3);

    exit_room(hall, 0, 1);
    exit_lobby(hall, 1);

    int * tmp = getLobbyinfo(hall);
    for(int i = 0; i < 20; i++) {
	printf("%i : %d players\n", i, *tmp);
	tmp++;
    }
}
#endif
