#ifndef _USERDATABASE_
#define _USERDATABASE_

#include <string.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <limits.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdlib.h>
#include <pthread.h>

#include "alloc.c"

typedef struct user {
    char name[20];
    char password[20];
    bool active;
    /*more stuffs, such as game data, can be futher added*/
} user;

typedef struct userData {
    char * data; //data block that holds the binary tree of users
    size_t data_size; // curent size of user data
    size_t capacity;
    int curr_read;
    int curr_write;
    pthread_mutex_t protector;
    pthread_cond_t cond;
} userDataBase;

typedef struct treeNode {
    user usr;
    int userNum;
    size_t left_child;
    size_t right_child;
    int curr_level;
} treeNode;

//SSIZE_MAX
int write_userData_to_file (userDataBase * ud, char * filename) { 
    int fd = open(filename, O_TRUNC | O_WRONLY | O_CREAT, 0666);
    write(fd, "GUDF", 4); //an arbitrary start value for user data file

    char buffer[sizeof(size_t)];

    snprintf(buffer, sizeof(size_t), "%lu", ud->data_size);
    write(fd, buffer, sizeof(size_t));

    snprintf(buffer, sizeof(size_t), "%lu", ud->capacity);
    write(fd, buffer, sizeof(size_t));

    /*
    if(ud->data_size > SSIZE_MAX) {
	size_t curr_size = ud->data_size;
	char * curr_data = ud->data;
	while(curr_size > SSIZE_MAX) {
	    write(fd, curr_data, SSIZE_MAX);
	    curr_size -= SSIZE_MAX;
	    curr_data += SSIZE_MAX;
	}
	write(fd, curr_data, SSIZE_MAX);
    }
    */
    //else {
	write(fd, ud->data, ud->data_size);	 
    //}
    close(fd);
    return 0;
}

int load_userData_from_file (userDataBase * ud, char * filename) {
    int fd = open(filename, O_RDONLY);
    char buffer[4];
    read(fd, buffer, 4);
    if(strcmp(buffer, "GUDF") != 0) {
	printf("Invalid file %s!\n", filename);
	return 1;
    }
    char buffer2[sizeof(size_t)];
    size_t size = 0;
    size_t capacity = 0;

    read(fd, buffer2, sizeof(size_t));
    sscanf(buffer2, "%lu", &size);

    read(fd, buffer2, sizeof(size_t));
    sscanf(buffer2, "%lu", &capacity);

    ud->data_size = size;
    ud->capacity = capacity;
    ud->data = mem_alloc(capacity);
    read(fd, ud->data, size);
    close(fd);
}

int userData_init(userDataBase * database) {
    database->data = mem_alloc(sizeof(user)*128);
    database->data_size = 0;
    database->capacity = (sizeof(user)*128);
    database->curr_read = 0;
    database->curr_write = 0;
    pthread_mutex_init(&database->protector, NULL);
    pthread_cond_init(&database->cond, NULL);
}

user * findUser(userDataBase * ud, char * username) {
    void * file = (void*)ud->data;
    treeNode * curr = (treeNode*)ud->data;
    while(1) {
	char * name = curr->usr.name;
	//printf("%s\n", name);
        int cmp = strcmp(name, username);
        if(cmp==0) {
            return &curr->usr;
        }
        else {
            if(cmp < 0 && curr->right_child != 0) {
                curr = file + curr->right_child;
            }
            else if(cmp > 0 && curr->left_child != 0){
                curr = file + curr->left_child;
            }
            else {
                return NULL;
            }
        }
    }
}

int userLogin(userDataBase * ud, char * name, char * password) {
    pthread_mutex_lock(&ud->protector);
    while(ud->curr_write > 0) pthread_cond_wait(&ud->cond, &ud->protector);
    ud->curr_read++;
    pthread_mutex_unlock(&ud->protector);

    user * tmp = findUser(ud, name);
    if(!tmp) {
	pthread_mutex_lock(&ud->protector);
	ud->curr_read--;
	pthread_cond_broadcast(&ud->cond);
        pthread_mutex_unlock(&ud->protector);
	return 1;
    }
    if(strcmp(password, tmp->password) != 0) {
	pthread_mutex_lock(&ud->protector);
	ud->curr_read--;
	pthread_cond_broadcast(&ud->cond);
	pthread_mutex_unlock(&ud->protector);
	return 2;
    }
    else {
	tmp->active = 1;
	pthread_mutex_lock(&ud->protector);
	ud->curr_read--;
	pthread_cond_broadcast(&ud->cond);
	pthread_mutex_unlock(&ud->protector);
	return 0;
    }
}

/*
char * findUserPassword(userDataBase * ud, char * username) {
    char * rt = malloc(21);
    user * tmp = findUser(ud, username);
    if(!tmp) {
	free(rt);
	return NULL;
    }
    else {
        strcpy(rt, tmp->password);
        return rt;
    }
}
*/
void my_strcpy(char * a, char * b) {
    for(int i = 0; i < 6; i++) {
	*a = *b;
	a++;
	b++;
    }
}

void usrcpy(user * dest, user * sour) {
    my_strcpy(dest->name, sour->name);
    my_strcpy(dest->password, sour->password);
    dest->active = sour->active;
}

size_t max(int a, int b) {
    if(a > b) return a;
    else return b;
}

void updateNodeLevel(void * bof, treeNode * curr) {
    treeNode * left;
    int left_level;

    if(curr->left_child == 0) {
        left = NULL;
        left_level = -1;
    }
    else {
        left = bof + curr->left_child;
        left_level = left->curr_level;
    }

    treeNode * right;
    int right_level;
    if(curr->right_child == 0) {
	right = NULL;
	right_level = -1;
    }
    else {
	right = bof + curr->right_child;
	right_level = right->curr_level;
    }
    curr->curr_level = 1 + max(left_level, right_level);
}

void get_child(void * bof, treeNode * curr, treeNode ** right, treeNode ** left,
	int * left_level, int * right_level) {
   if(curr->left_child == 0) {
       *left = NULL;
       *left_level = -1;
   }
   else {
       *left = bof + curr->left_child;
       *left_level = (*left)->curr_level;
   }

   if(curr->right_child == 0) {
       *right = NULL;
       *right_level = -1;
   }
   else {
       *right = bof + curr->right_child;
       *right_level = (*right)->curr_level;
   }
}

void right_shift(treeNode * curr, treeNode * left, int right_level) {
    treeNode tmp;
    size_t left_right = left->right_child;

    left->right_child = curr->left_child;
    curr->left_child = left_right;
    curr->curr_level = right_level + 1;

    memcpy(&tmp, curr, sizeof(treeNode));
    memcpy(curr, left, sizeof(treeNode));
    memcpy(left, &tmp, sizeof(treeNode));
}

void left_shift(treeNode * curr, treeNode * right, int left_level) {
    treeNode tmp;
    size_t right_left = right->left_child;

    right->left_child = curr->right_child;
    curr->right_child = right_left;
    curr->curr_level = left_level + 1;

    memcpy(&tmp, curr, sizeof(treeNode));
    memcpy(curr, right, sizeof(treeNode));
    memcpy(right, &tmp, sizeof(treeNode));
}

int addUserHelper(void * bof, treeNode * curr, treeNode * new, 
				size_t new_position, userDataBase * ud) {
    char * name = curr->usr.name;
    int cmp = strcmp(curr->usr.name, new->usr.name);
    if(cmp==0) {
	printf("%s already exist!\n", curr->usr.name);
        return -1;
    }
    else if(cmp < 0) {
	if(curr->right_child == 0) {
	    curr->right_child = new_position;
	    curr->curr_level = 1;
	    return 1;
	}
	else {
            int tmp = addUserHelper(bof, bof+curr->right_child, new, new_position, ud);
	    if(tmp == -1) return -1;
	    
	    treeNode * left;
	    int left_level;
	    treeNode * right;
	    int right_level;
	    get_child(bof, curr, &right, &left, &left_level, &right_level);

	    curr->curr_level = 1 + max(left_level, right_level);	   
	    pthread_mutex_lock(&ud->protector); 
	    ud->curr_write++;
	    if(left_level == right_level - 2) {	
		treeNode * right_left;
		int right_left_level;
		treeNode * right_right;
		int right_right_level;
		get_child(bof, right, &right_right, &right_left, &right_left_level, &right_right_level);
		if(right_right_level < right_left_level) 
			right_shift(right, right_left, right_left_level);

		left_shift(curr, right, left_level);
	    }
	    ud->curr_write--;
	    updateNodeLevel(bof, curr);	 
	    pthread_mutex_unlock(&ud->protector);   
	}
    }
    else {
	if(curr->left_child == 0){
	    curr->left_child = new_position;
	    curr->curr_level = 1;
	    return 0;
	}
        else {
	    int tmp = addUserHelper(bof, bof+curr->left_child, new, new_position, ud);
	    if(tmp == -1) return -1;

	    treeNode * left;
            int left_level;
            treeNode * right;
            int right_level;
            get_child(bof, curr, &right, &left, &left_level, &right_level);
            
            curr->curr_level = 1 + max(left_level, right_level);

	    pthread_mutex_lock(&ud->protector);
	    ud->curr_write++; 
	    while(ud->curr_read > 0) pthread_cond_wait(&ud->cond, &ud->protector);
            if(right_level == left_level - 2) {
		treeNode * left_left;
                int left_left_level;
                treeNode * left_right;
                int left_right_level;
                get_child(bof, left, &left_right, &left_left, &left_left_level, &left_right_level);

		if(left_left_level < left_right_level)
                        left_shift(left, left_right, left_left_level);
                right_shift(curr, left, right_level);
            }	
	    updateNodeLevel(bof, curr);  
	    ud->curr_write--;
	    pthread_cond_broadcast(&ud->cond);
	    pthread_mutex_unlock(&ud->protector);  
	}
    }
}

pthread_mutex_t m = PTHREAD_MUTEX_INITIALIZER;
int addUser(userDataBase * ud, user * curr) {
    pthread_mutex_lock(&m);
    int rt;
    if(ud->data_size == 0) {
	treeNode * tr = (treeNode *)ud->data;
	usrcpy(&tr->usr, curr);

	tr->userNum = 0;
	tr->left_child = 0;
	tr->right_child = 0;
	tr->curr_level = 0;
	rt = 0;
    }
    else {
    	if(ud->data_size == ud->capacity) {
	    //printf("time for realloc\n");
	    ud->capacity *= 2;
	    ud->data = mem_realloc(ud->data, ud->capacity);
        }
	treeNode * new = (treeNode*)(ud->data + ud->data_size);
        //treeNode * tr = (treeNode *)ud->data;       
 
    	usrcpy(&(new->usr), curr);
	
	new->userNum = ud->data_size/sizeof(treeNode);
    	new->left_child = 0;
    	new->right_child = 0;
    	new->curr_level = 0;
        rt = addUserHelper(ud->data, (treeNode*)ud->data, new, ud->data_size, ud);	
    }
    if(rt != -1)ud->data_size += sizeof(treeNode);
    pthread_mutex_unlock(&m);
    return rt;
}

void print_all(userDataBase * ud) {
    for(int i = 0; i < ud->data_size; i+=sizeof(treeNode)) {
	treeNode * tmp = (treeNode*)(ud->data + i);
	printf(" %d. %s(%d) : %lu, %lu\n",i/sizeof(treeNode), tmp->usr.name, tmp->curr_level, tmp->left_child/sizeof(treeNode), tmp->right_child/sizeof(treeNode));
    }
}
#endif
