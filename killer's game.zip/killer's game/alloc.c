#ifndef _ALLOC_
#define _ALLOC_
#include <pthread.h>
#include <stdlib.h>

pthread_mutex_t mu = PTHREAD_MUTEX_INITIALIZER;
void * mem_alloc(size_t size) {
    pthread_mutex_lock(&mu);
    void * tmp = malloc(size);
    pthread_mutex_unlock(&mu);
    return tmp;
}

void mem_free(void * ptr) {
    pthread_mutex_lock(&mu);
    free(ptr);
    pthread_mutex_unlock(&mu);
}

void * mem_realloc(void * ptr, size_t size) {
    pthread_mutex_lock(&mu);
    void * tmp = realloc(ptr, size);
    pthread_mutex_unlock(&mu);
    return tmp;
}
#endif
